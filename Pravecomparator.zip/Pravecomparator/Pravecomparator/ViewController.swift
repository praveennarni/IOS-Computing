//
//  ViewController.swift
//  Pravecomparator
//
//  Created by Narni,Praveen Babu on 9/5/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBOutlet weak var frOL: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitbtn(_ sender: Any) {
        
        var input = inputOL.text!
        
        let doubler = Double(input) ?? 0
        
        if(doubler >= 18){
            frOL.text = "You are Eligible to vote"
        }
        else{frOL.text = "You are not eligible to vote"}
        
        
    }
    
}

