//
//  ViewController.swift
//  DemoBMI
//
//  Created by Praveen Babu Narni on 11/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var weightOL: UITextField!
    
    
    @IBOutlet weak var heightOL: UITextField!
    var bmi = 0.0
    var imageNumber = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func calcBmi(_ sender: Any) {
        
        var weight = Double(weightOL.text!)
        
        var height = Double(heightOL.text!)
        
        bmi = Double((weight!/(height! * height!))*(703))
        
        if (bmi <= 18.4){
            imageNumber = "uw"}
        if(bmi > 18.5 || bmi < 25){
            imageNumber = "nrml"
        }
        else if(bmi >= 25 || bmi < 40){ imageNumber = "ow"
            
        }
        else{imageNumber = "ob"}
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if transition == "resultSegue"{
            var destination = segue .destination as! ResultViewController
            
            destination.mass = weightOL.text!
            destination.hgt = heightOL.text!
            destination.cbmi = String (bmi)
            destination.img = imageNumber
            
            
        }
        
    }
}
