//
//  ResultViewController.swift
//  DemoBMI
//
//  Created by Praveen Babu Narni on 11/2/23.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var weightOL: UILabel!
    
    
    @IBOutlet weak var heightOL: UILabel!
    
    
    @IBOutlet weak var calculatedBmiOL: UILabel!
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    var mass = ""
    var hgt = ""
    var cbmi = ""
    var img = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        weightOL.text! += mass
        heightOL.text! += hgt
        calculatedBmiOL.text! += cbmi
        imageViewOL.image = UIImage(named: img)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
